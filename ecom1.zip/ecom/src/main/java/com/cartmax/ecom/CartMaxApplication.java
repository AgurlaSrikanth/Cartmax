package com.cartmax.ecom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CartMaxApplication {

	public static void main(String[] args) {
		SpringApplication.run(CartMaxApplication.class, args);
	}

}
